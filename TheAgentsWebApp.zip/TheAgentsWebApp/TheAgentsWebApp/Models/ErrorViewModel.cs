public class ErrorViewModel
{
    public string RequestId { get; }
    public bool ShowRequestId { get; }

    public ErrorViewModel(string requestId, bool showRequestId)
    {
        RequestId = requestId;
        ShowRequestId = showRequestId;
    }
}

﻿using Newtonsoft.Json;
using System;

namespace TheAgentsWebApp.Models
{
    public class DecimalConverter : JsonConverter<decimal?>
    {
        public override decimal? ReadJson(JsonReader reader, Type objectType, decimal? existingValue, bool hasExistingValue, JsonSerializer serializer)
        {
            if (reader.TokenType == JsonToken.String)
            {
                var stringValue = reader.Value.ToString();
                if (stringValue == "POA")
                {
                    return null; // Or handle "POA" in a specific way
                }

                if (decimal.TryParse(stringValue, out var result))
                {
                    return result;
                }
            }

            if (reader.TokenType == JsonToken.Float || reader.TokenType == JsonToken.Integer)
            {
                return Convert.ToDecimal(reader.Value);
            }

            return null;
        }

        public override void WriteJson(JsonWriter writer, decimal? value, JsonSerializer serializer)
        {
            writer.WriteValue(value);
        }
    }
}

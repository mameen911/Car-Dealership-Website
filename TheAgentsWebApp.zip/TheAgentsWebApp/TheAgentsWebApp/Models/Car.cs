﻿using Newtonsoft.Json;

namespace TheAgentsWebApp.Models
{
    public class Car
    {
        [JsonProperty("id")]
        public int Id { get; set; }

        [JsonProperty("dealerId")]
        public int DealerId { get; set; }

        [JsonProperty("make")]
        public string Make { get; set; }

        [JsonProperty("model")]
        public string Model { get; set; }

        [JsonProperty("variant")]
        public string Variant { get; set; }

        [JsonProperty("year")]
        public int Year { get; set; }

        [JsonProperty("mileageInKm")]
        public int MileageInKm { get; set; }

        [JsonProperty("price")]
        [JsonConverter(typeof(DecimalConverter))]
        public decimal? Price { get; set; }

        [JsonProperty("colour")]
        public string Colour { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("imageUrls")]
        public List<string> ImageUrls { get; set; }

        [JsonProperty("bodyType")]
        public string BodyType { get; set; }

        [JsonProperty("doors")]
        public int Doors { get; set; }

        [JsonProperty("engineCapacityInCc")]
        public decimal EngineCapacityInCc { get; set; }

        [JsonProperty("fuelType")]
        public string FuelType { get; set; }

        [JsonProperty("transmissionDrive")]
        public string TransmissionDrive { get; set; }

        [JsonProperty("transmission")]
        public string Transmission { get; set; }

        [JsonProperty("dealerContactInformation")]
        public DealerContactInformation DealerContactInformation { get; set; }
    }

    public class DealerContactInformation
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("emailAddress")]
        public string EmailAddress { get; set; }

        [JsonProperty("contactNumber")]
        public string ContactNumber { get; set; }

        [JsonProperty("address")]
        public Address Address { get; set; }
    }

    public class Address
    {
        [JsonProperty("line1")]
        public string Line1 { get; set; }

        [JsonProperty("postalCode")]
        public string PostalCode { get; set; }

        [JsonProperty("suburb")]
        public string Suburb { get; set; }

        [JsonProperty("city")]
        public string City { get; set; }

        [JsonProperty("province")]
        public string Province { get; set; }
    }
}

using Microsoft.AspNetCore.Mvc;
using TheAgentsWebApp.Models;

namespace TheAgentsWebApp.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult Error()
        {
            // Get the request ID from the current HTTP context
            var requestId = HttpContext.TraceIdentifier;

            // Check if the request ID is not null or empty
            var showRequestId = !string.IsNullOrEmpty(requestId);

            // Create an instance of ErrorViewModel with the request ID and whether to show it
            var model = new ErrorViewModel(requestId, showRequestId);

            // Return the Error view with the model
            return View(model);
        }

    }
}

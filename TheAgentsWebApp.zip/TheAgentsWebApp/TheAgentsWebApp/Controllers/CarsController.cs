﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TheAgentsWebApp.Services;
using System.Threading.Tasks;
using TheAgentsWebApp.Models;

namespace TheAgentsWebApp.Controllers
{
    public class CarsController : Controller
    {
        private readonly ICarService _carService;
        private readonly ILogger<CarsController> _logger;

        public CarsController(ICarService carService, ILogger<CarsController> logger)
        {
            _carService = carService;
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                var cars = await _carService.GetCarsAsync();
                if (cars == null || cars.Count == 0)
                {
                    ViewBag.ErrorMessage = "No cars available at the moment.";
                    return View();
                }

                return View(cars);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching car data.");
                ViewBag.ErrorMessage = "An error occurred while fetching car data. Please try again later.";
                return View("Error");
            }
        }

        public async Task<IActionResult> Details(int id)
        {
            try
            {
                var car = await _carService.GetCarByIdAsync(id);
                if (car == null)
                {
                    ViewBag.ErrorMessage = "Car not found.";
                    return View("Error");
                }

                return View(car);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching car details.");
                ViewBag.ErrorMessage = "An error occurred while fetching car details. Please try again later.";
                return View("Error");
            }
        }

    }
}


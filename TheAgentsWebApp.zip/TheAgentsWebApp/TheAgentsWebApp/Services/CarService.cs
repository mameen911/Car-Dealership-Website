﻿using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using TheAgentsWebApp.Models;
using TheAgentsWebApp.Services;

public class CarService : ICarService
{
    private readonly HttpClient _httpClient;
    private readonly IConfiguration _configuration;
    private readonly ILogger<CarService> _logger;
    private const int MaxRetries = 3;

    public CarService(HttpClient httpClient, IConfiguration configuration, ILogger<CarService> logger)
    {
        _httpClient = httpClient;
        _configuration = configuration;
        _logger = logger;
    }

    public async Task<List<Car>> GetCarsAsync()
    {
        var baseUrl = _configuration["ApiSettings:BaseUrl"];
        var username = _configuration["ApiSettings:Username"];
        var password = _configuration["ApiSettings:Password"];

        var byteArray = Encoding.ASCII.GetBytes($"{username}:{password}");
        _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

        int retryCount = 0;
        HttpResponseMessage response = null;

        while (retryCount < MaxRetries)
        {
            try
            {
                response = await _httpClient.GetAsync(baseUrl);

                if (response.StatusCode == HttpStatusCode.TooManyRequests)
                {
                    retryCount++;
                    var retryAfter = response.Headers.RetryAfter?.Delta?.TotalMilliseconds ?? 1000;
                    await Task.Delay((int)retryAfter);
                    continue;
                }

                response.EnsureSuccessStatusCode();

                var content = await response.Content.ReadAsStringAsync();
                var cars = JsonConvert.DeserializeObject<List<Car>>(content);

                return cars;
            }
            catch (HttpRequestException ex) when (ex.StatusCode == HttpStatusCode.TooManyRequests)
            {
                retryCount++;
                var retryAfter = response?.Headers.RetryAfter?.Delta?.TotalMilliseconds ?? 1000;
                await Task.Delay((int)retryAfter);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching car data.");
                throw new ApplicationException("An error occurred while fetching car data.", ex);
            }
        }

        throw new Exception("Failed to get cars after multiple retries.");
    }

    public async Task<Car> GetCarByIdAsync(int id)
    {
        var baseUrl = _configuration["ApiSettings:BaseUrl"];
        var username = _configuration["ApiSettings:Username"];
        var password = _configuration["ApiSettings:Password"];

        var byteArray = Encoding.ASCII.GetBytes($"{username}:{password}");
        _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

        int retryCount = 0;
        HttpResponseMessage response = null;

        while (retryCount < MaxRetries)
        {
            try
            {
                var requestUrl = $"{baseUrl}/{id}";
                _logger.LogInformation($"Fetching car details from: {requestUrl}");

                response = await _httpClient.GetAsync(requestUrl);

                if (response.StatusCode == HttpStatusCode.TooManyRequests)
                {
                    retryCount++;
                    var retryAfter = response.Headers.RetryAfter?.Delta?.TotalMilliseconds ?? 1000;
                    await Task.Delay((int)retryAfter);
                    continue;
                }

                if (response.StatusCode == HttpStatusCode.NotFound)
                {
                    throw new KeyNotFoundException($"Car with ID {id} not found.");
                }

                response.EnsureSuccessStatusCode();

                var content = await response.Content.ReadAsStringAsync();
                var car = JsonConvert.DeserializeObject<Car>(content);

                return car;
            }
            catch (HttpRequestException ex) when (ex.StatusCode == HttpStatusCode.TooManyRequests)
            {
                retryCount++;
                var retryAfter = response?.Headers.RetryAfter?.Delta?.TotalMilliseconds ?? 1000;
                await Task.Delay((int)retryAfter);
            }
            catch (KeyNotFoundException ex)
            {
                _logger.LogError(ex, $"Car with ID {id} not found.");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching car details.");
                throw new ApplicationException("An error occurred while fetching car details.", ex);
            }
        }

        throw new Exception("Failed to get car details after multiple retries.");
    }
}


﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TheAgentsWebApp.Models;

namespace TheAgentsWebApp.Services
{
    public interface ICarService
    {
        Task<List<Car>> GetCarsAsync();
        Task<Car> GetCarByIdAsync(int id);
    }
}
